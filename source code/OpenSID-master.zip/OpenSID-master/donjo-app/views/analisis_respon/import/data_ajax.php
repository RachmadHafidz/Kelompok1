<div class='modal-body'>
	<div class="row">
		<div class="col-sm-12">
			<div class="box-body">
				<p>
					Unduh data respon dalam format yang siap diimpor. Gunakan untuk mengisi/mengupdate data respon secara massal atau untuk memasukkan data respon ke aplikasi lain.
					<div class="timeline-footer row">
						<a href="<?= site_url()?>analisis_respon/data_unduh/1" class="btn btn-social btn-flat btn-info btn-sm visible-xs-block visible-sm-inline-block visible-md-inline-block visible-lg-inline-block margin" wrap target="_blank"><i class="fa fa-download"></i> Form Excel + Isi Data</a>
					</div>
				</p>
				<p>
				Unduh form kosong menampilkan daftar kode untuk setiap kolom.
					<div class="timeline-footer row">
						<a href="<?= site_url()?>analisis_respon/data_unduh/2" class="btn btn-social btn-flat btn-info btn-sm visible-xs-block visible-sm-inline-block visible-md-inline-block visible-lg-inline-block margin" wrap target="_blank"><i class="fa fa-download"></i> Form Excel + Kode Data</a>
					</div>
				</p>
			</div>
		</div>
	</div>
</div>
<div class="modal-footer">
	<button type="reset" class="btn btn-social btn-flat btn-danger btn-sm" data-dismiss="modal"><i class='fa fa-sign-out'></i> Tutup</button>
</div>
